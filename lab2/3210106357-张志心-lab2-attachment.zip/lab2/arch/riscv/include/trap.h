#ifndef _TRAP_H
#define _TRAP_H

void trap_handler(unsigned long scause, unsigned long sepc);

#endif